class UserNotFound(Exception):
    pass