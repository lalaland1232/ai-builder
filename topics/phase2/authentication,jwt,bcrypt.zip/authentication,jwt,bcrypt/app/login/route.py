from fastapi import APIRouter, Depends
from app.core.schemas import LoginRequest
from app.db.database import get_db
from app.db.models import User, Artifact
import bcrypt
from app.login.service import LoginService


router = APIRouter()


def get_service(db=Depends(get_db)):
    return LoginService(db)
    
@router.post("/login")
def login(request:LoginRequest,service=Depends(get_service)):
    return service.login(request)
    
