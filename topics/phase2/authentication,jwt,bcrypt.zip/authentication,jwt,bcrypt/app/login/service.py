from app.core.security import authenticate_user, create_access_token
from fastapi import HTTPException
class LoginService:
    def __init__(self,db):
        self.db = db
        
    def login(self,request):
        user = authenticate_user(email=request.email,password=request.password,db=self.db)
        if user:
            claims={"sub":str(user.id),"type":"access"}
            access_token = create_access_token(data=claims)
            return {"access_token":access_token,"token_type":"bearer"}
        raise HTTPException(status_code=401,detail="Invalid email or password")

    
    