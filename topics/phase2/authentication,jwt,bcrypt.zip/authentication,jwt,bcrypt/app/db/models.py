from app.db.database import Base
from sqlalchemy import Column, ForeignKey, Integer, LargeBinary, String
from sqlalchemy.orm import relationship , Mapped , mapped_column

class User(Base):
    __tablename__="users"
    __table_args__={"schema":"prep_day10"}
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    email:Mapped[str]=mapped_column(String,unique=True,nullable=False)
    name:Mapped[str]=mapped_column(String,nullable=False)

    artifact:Mapped["Artifact"]=relationship(back_populates="user")

class Artifact(Base):
    __tablename__="artifacts"
    __table_args__={"schema":"prep_day10"}
    id:Mapped[int]=mapped_column(ForeignKey("prep_day10.users.id"),primary_key=True)
    artifact:Mapped[bytes]=mapped_column(LargeBinary,nullable=False)

    user:Mapped["User"]=relationship(back_populates="artifact")