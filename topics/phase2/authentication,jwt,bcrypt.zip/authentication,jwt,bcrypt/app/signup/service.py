from app.core.security import create_artifact, create_access_token
class SignUpService:
    def __init__(self, repo, db):
        self.repo = repo
        self.db = db

    def signup(self, request):
        if self.repo.find_user_by_email(request.email):
            raise ValueError("User with this email already exists")
        
        try:
            user = self.repo.add_user(request)
            create_artifact(password=request.password, id=user.id, db=self.db)
            self.db.commit()
            
            token = create_access_token(data={"sub": str(user.id), "type": "access"})
            print(token)
            return {"access_token": token, "token_type": "bearer"}
        except Exception as e:
            self.db.rollback()
            raise e
