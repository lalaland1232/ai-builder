from dotenv import load_dotenv
load_dotenv()
from fastapi import Depends, FastAPI
from app.me.route import merouter
from app.login.route import router
from app.db.database import Base,engine
from app.db.models import *
from app.signup.route import signup_router
from app.core.security import get_token
Base.metadata.create_all(bind=engine)
app = FastAPI()
app.include_router(merouter)
app.include_router(router)
app.include_router(signup_router)
@app.get("/get_token")
def get_token(token=Depends(get_token)):
    return {"token": token} 